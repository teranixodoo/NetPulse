# backend/backup.py — MikroTik backup engine (export .rsc přes SSH)
#
# Export konfigurace probíhá vždy přes SSH (/export verbose).
# RouterOS API se používá pouze pro zjištění verze ROS.
# Zálohy: /backups/{device_uuid}/{hostname}_{timestamp}.rsc

from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

log = logging.getLogger("netpulse.backup")

BACKUP_ROOT = Path(os.getenv("BACKUP_DIR", "/backups"))


# ---------------------------------------------------------------------------
# Výsledek zálohy
# ---------------------------------------------------------------------------
class BackupResult:
    def __init__(self):
        self.backup_type:      str            = "export"
        self.success:          bool           = False
        self.filepath:         Optional[Path] = None
        self.filename:         str            = ""
        self.file_size_bytes:  Optional[int]  = None
        self.mikrotik_version: Optional[str]  = None
        self.duration_ms:      Optional[int]  = None
        self.error:            Optional[str]  = None


# ---------------------------------------------------------------------------
# Pomocné funkce
# ---------------------------------------------------------------------------

def _ensure_backup_dir(device_uuid: str) -> Path:
    d = BACKUP_ROOT / device_uuid
    d.mkdir(parents=True, exist_ok=True)
    return d


def _make_filename(hostname: str) -> str:
    ts        = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
    safe_host = "".join(c if c.isalnum() or c in "-_." else "_" for c in (hostname or "device"))
    return f"{safe_host}_{ts}.rsc"


def _decrypt(password_cipher: str, cipher_obj) -> str:
    if not cipher_obj or not password_cipher:
        return password_cipher or ""
    try:
        return cipher_obj.decrypt(password_cipher.encode()).decode()
    except Exception:
        return password_cipher


def _extract_ros_version(text: str) -> Optional[str]:
    for line in text.splitlines()[:5]:
        m = re.search(r"v(\d+\.\d+[\.\d]*)", line)
        if m:
            return m.group(1)
    return None


# ---------------------------------------------------------------------------
# Verze ROS přes API (volitelné — nepřerušíme zálohu pokud selže)
# ---------------------------------------------------------------------------

def _get_ros_version_via_api(
    ip: str, port: int, username: str, password: str, use_ssl: bool
) -> Optional[str]:
    """Synchronní — spouštět v executoru."""
    try:
        import routeros_api
        import ssl as _ssl

        ssl_variants = []
        if use_ssl:
            ssl_variants.append({"use_ssl": True, "ssl_verify": False,
                                  "ssl_verify_hostname": False, "ssl_context": None})
            try:
                ctx = _ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode    = _ssl.CERT_NONE
                ctx.set_ciphers("ALL:@SECLEVEL=0")
                ssl_variants.append({"use_ssl": True, "ssl_verify": False,
                                      "ssl_verify_hostname": False, "ssl_context": ctx})
            except Exception:
                pass
        else:
            ssl_variants.append({"use_ssl": False, "ssl_verify": False,
                                  "ssl_verify_hostname": False, "ssl_context": None})

        for ssl_opt in ssl_variants:
            try:
                api = routeros_api.RouterOsApiPool(
                    ip, username=username, password=password,
                    port=port, plaintext_login=True, **ssl_opt,
                ).get_api()
                res = api.get_resource("/system/resource").get()
                return res[0].get("version") if res else None
            except Exception:
                continue
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Export přes SSH — hlavní metoda zálohy
# ---------------------------------------------------------------------------

async def _export_via_ssh(
    ip: str, cred: dict, cipher,
    hostname: str, device_uuid: str,
    auth_snapshot: dict = None,
    api_creds: list = None,
    timeout: float = 60.0,
) -> BackupResult:
    result = BackupResult()
    t0     = time.monotonic()

    try:
        import asyncssh
    except ImportError:
        result.error = "asyncssh není nainstalován"
        return result

    # Parametry SSH — ze snapshotu pokud existuje a patří SSH metodě
    if auth_snapshot and auth_snapshot.get("auth_type") == "ssh":
        port     = int(auth_snapshot.get("port") or cred.get("port") or 22)
        username = auth_snapshot.get("username") or cred.get("username") or "admin"
        log.info(f"SSH backup {ip}:{port} — parametry ze snapshotu user={username}")
    else:
        port     = int(cred.get("port") or 22)
        username = cred.get("username") or "admin"

    password = _decrypt(cred.get("password_cipher", ""), cipher)

    try:
        async with asyncssh.connect(
            host=ip, port=port, username=username, password=password,
            known_hosts=None, connect_timeout=15,
        ) as conn:
            # Zkusíme verbose export, fallback na normální
            r           = await conn.run("/export verbose", timeout=timeout - 10)
            export_text = r.stdout or ""
            if not export_text.strip():
                r           = await conn.run("/export", timeout=timeout - 10)
                export_text = r.stdout or ""

        if not export_text.strip():
            result.error = "SSH export vrátil prázdný výstup"
            return result

        # Uložíme soubor
        backup_dir = _ensure_backup_dir(device_uuid)
        filename   = _make_filename(hostname)
        filepath   = backup_dir / filename
        filepath.write_text(export_text, encoding="utf-8")

        # Pokusíme se zjistit verzi ROS ze záhlaví exportu nebo přes API
        version = _extract_ros_version(export_text)
        if not version and api_creds:
            # Zkusíme verzi přes API (neblokující — v executoru)
            for api_cred in api_creds:
                api_port     = int(api_cred.get("port") or 8728)
                api_username = api_cred.get("username") or "admin"
                api_password = _decrypt(api_cred.get("password_cipher", ""), cipher)
                api_use_ssl  = api_port in (8729, 443) or api_port >= 8700
                loop         = asyncio.get_event_loop()
                try:
                    version = await asyncio.wait_for(
                        loop.run_in_executor(
                            None, _get_ros_version_via_api,
                            ip, api_port, api_username, api_password, api_use_ssl
                        ),
                        timeout=10
                    )
                    if version:
                        break
                except Exception:
                    continue

        result.success          = True
        result.filepath         = filepath
        result.filename         = filename
        result.file_size_bytes  = filepath.stat().st_size
        result.mikrotik_version = version
        result.duration_ms      = int((time.monotonic() - t0) * 1000)

        log.info(
            f"SSH export OK: ip={ip} size={result.file_size_bytes}B "
            f"version={version} file={filename}"
        )

    except asyncio.TimeoutError:
        result.error = f"Timeout SSH exportu ({timeout}s)"
    except Exception as e:
        result.error = str(e)[:400]
        log.warning(f"SSH export {ip} chyba: {result.error}")

    return result


# ---------------------------------------------------------------------------
# Hlavní funkce
# ---------------------------------------------------------------------------

async def backup_mikrotik(
    ip:                      str,
    creds:                   list,
    cipher,
    device_uuid:             str,
    hostname:                str,
    triggered_by:            str   = "manual",
    timeout:                 float = 90.0,
    last_successful_cred_id: int   = None,
    last_successful_auth:    dict  = None,
) -> BackupResult:
    """
    Export záloha (.rsc) MikroTik zařízení přes SSH.
    Priorita SSH credentials: úspěšný při posledním pollu → ostatní.
    Verze ROS se zjišťuje přes API (volitelně).
    """
    ssh_creds = [c for c in creds if c.get("auth_type") == "ssh"]
    api_creds = [c for c in creds if c.get("auth_type") == "api"]

    log.info(
        f"Backup zahájen: ip={ip} host={hostname} "
        f"ssh={len(ssh_creds)} api={len(api_creds)} "
        f"snapshot={'ano' if last_successful_auth else 'ne'} "
        f"preferred_cred_id={last_successful_cred_id}"
    )

    if not ssh_creds:
        result       = BackupResult()
        result.error = "Záloha vyžaduje SSH přihlašovací profil"
        log.warning(f"Backup FAIL: ip={ip} — {result.error}")
        return result

    # Úspěšný credential při posledním pollu jde první
    def _sorted_ssh(cred_list: list) -> list:
        if not last_successful_cred_id:
            return cred_list
        return sorted(cred_list, key=lambda c: 0 if c.get("id") == last_successful_cred_id else 1)

    def _snapshot_for(cred: dict) -> dict | None:
        if last_successful_auth and last_successful_auth.get("credential_id") == cred.get("id"):
            return last_successful_auth
        return None

    for cred in _sorted_ssh(ssh_creds):
        r = await _export_via_ssh(
            ip, cred, cipher, hostname, device_uuid,
            auth_snapshot = _snapshot_for(cred),
            api_creds     = api_creds,
            timeout       = timeout,
        )
        if r.success:
            return r
        log.warning(f"SSH export selhal ({cred.get('name','?')}): {r.error}")

    result       = BackupResult()
    result.error = "Export selhal přes všechny SSH profily"
    log.warning(f"Backup FAIL: ip={ip} — {result.error}")
    return result


# ---------------------------------------------------------------------------
# Formátování velikosti
# ---------------------------------------------------------------------------

def format_file_size(size_bytes: Optional[int]) -> str:
    if size_bytes is None:
        return "—"
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes / (1024 * 1024):.2f} MB"
